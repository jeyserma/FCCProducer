*
* BoX-FORMATs for nice and flexible outputs
      CHARACTER*80      bxope,bxclo,bxtxt,bxl1i,bxl1f,bxl2f,bxl1g,bxl2g
      PARAMETER (
     $  bxope ='(//1x,15(5h*****)    )',
     $  bxtxt ='(1x,1h*,                  a48,25x,    1h*)',
     $  bxl1i ='(1x,1h*,i17,                 16x, a20,a12,a7, 1x,1h*)',
     $  bxl1f ='(1x,1h*,f17.8,               16x, a20,a12,a7, 1x,1h*)',
     $  bxl2f ='(1x,1h*,f17.8, 4h  +-, f11.8, 1x, a20,a12,a7, 1x,1h*)',
     $  bxl1g ='(1x,1h*,g17.8,               16x, a20,a12,a7, 1x,1h*)',
     $  bxl2g ='(1x,1h*,g17.8, 4h  +-, f11.8, 1x, a20,a12,a7, 1x,1h*)',
     $  bxclo ='(1x,15(5h*****)/   )'
     $ )
*///////////////////////////////////////////////////////////////////////////////
